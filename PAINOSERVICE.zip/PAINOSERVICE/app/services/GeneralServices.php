<?php

class GeneralService
{

    protected $Mensaje;
    protected $MensajeError;
    protected $Estado;


    public function setMensaje($Mensaje)
    {
        $this->Mensaje = $Mensaje;
    }

    public function getMensaje()
    {
        return $this->Mensaje;
    }

    public function setMensajeError($MensajeError)
    {
        $this->MensajeError = $MensajeError;
    }

    public function getMensajeError()
    {
        return $this->MensajeError;
    }

    public function setEstado($Estado)
    {
        $this->Estado = $Estado;
    }

    public function getEstado()
    {
        return $this->Estado;
    }
}
