<?php 

header('Access-Control-Allow-Origin: *'); 
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');

header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
require_once dirname(__FILE__, 3) . "./app/db/DB.php";
require_once dirname(__FILE__, 3) . "./app/services/GeneralServices.php";

class Usuario
{
    public function __CONSTRUCT()
    {
        $this->db=new Conexion(); 
    }

    public function insrt_usuario($usu,$pass,$dni)
    {
        try
        {
            $sql = 'CALL sp_insrt_usuario(?,?,?)';
            $claveEncriptada = sha1("PAI".$pass."20");
            $param = $array($usu,$claveEncriptada,$dni);
            $data = $this->db->query($sql,$param);
            return $data;
        }
        catch(Exception $e)
        {
            $this->Estado=-1;
            $this->Mensaje='Error en el proceso, consulte con el administrador.';
            $this->MensajeError=$e->getMessage();
        }
    }
}

?>