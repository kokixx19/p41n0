<?php

header('Access-Control-Allow-Origin: *'); 
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');

header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
require_once dirname(__FILE__, 3) . "./app/db/DB.php";
require_once dirname(__FILE__, 3) . "./app/services/GeneralServices.php";

class SolicitudVIP
{
    public function __construct()
    {
        $this->db = new Conexion;
    }    
    public  function inst_SolicitudVIP($PerIdenro,$PerParticipacion,$PerTide,$AutoObserv,$UniDeclarante,$PermiEstado,$PermiCodPro,$PerIdenroR,$PerTideR)
    {
       try{
           $sql="Call sp_insrt_SolicitudVIP(?,?,?,?,?,?,?,?,?)";
           $param=array($PerIdenro,$PerParticipacion,$PerTide,$AutoObserv,$UniDeclarante,$PermiEstado,$PermiCodPro,$PerIdenroR,$PerTideR);
           $data=$this->db->query($sql,$param);
           return $data;
       }catch(Exception $e){
        $this->Estado=-1;
        $this->Mensaje='Error en el proceso, consulte con el administrador.';
        $this->MensajeError=$e->getMessage(); 
       }
    }
    public  function sp_insrt_SolicitudVIPPadre($PerIdenro,$PerParticipacion,$PerTide,$AutoObserv,$UniDeclarante,$PermiEstado,$PermiCodPro)
    {
       try{
           $sql="Call sp_insrt_SolicitudVIPPadre(?,?,?,?,?,?,?)";
           $param=array($PerIdenro,$PerParticipacion,$PerTide,$AutoObserv,$UniDeclarante,$PermiEstado,$PermiCodPro);
           $data=$this->db->query($sql,$param);
           return $data;
       }catch(Exception $e){
        $this->Estado=-1;
        $this->Mensaje='Error en el proceso, consulte con el administrador.';
        $this->MensajeError=$e->getMessage(); 
       }
    }   

    public function sp_insrt_SolicitudVIPHijo($PerTideP,$PerIdenroP,$PerIdenro,$PerTide,$AutoObserv,$NumPartida,$AutoTraVia,$AutoFchVia,$AutoDeclaracion,$PermiDestino,$PermiTip,$PermiCodPro){
      try{
          $sql="Call sp_insrt_SolicitudVHijo(?,?,?,?,?,?,?,?,?,?,?,?)";
          $param=array($PerTideP,$PerIdenroP,$PerIdenro,$PerTide,$AutoObserv,$NumPartida,$AutoTraVia,$AutoFchVia,$AutoDeclaracion,$PermiDestino,$PermiTip,$PermiCodPro);
          $data=$this->db->query($sql,$param);
          return $data;
      }catch(Exception $e){
        $this->Estado=-1;
        $this->Mensaje='Error en el proceso, consulte con el administrador.';
        $this->MensajeError=$e->getMessage(); 
      }
    }
    public function sp_insrt_SolicitudVEPALL($PerTideP,$PerIdenroP,$PerIdenro,$PerParticipacion,$PerTide,$AutoObserv,$PermiEstado,$NumPartida,$UniDeclarante,$AutoSex,$PermiTip,$PermiCodPro){
        try{
            $sql="Call sp_insrt_SolicitudVALL(?,?,?,?,?,?,?,?,?,?,?,?)";
            $param=array($PerTideP,$PerIdenroP,$PerIdenro,$PerParticipacion,$PerTide,$AutoObserv,$PermiEstado,$NumPartida,$UniDeclarante,$AutoSex,$PermiTip,$PermiCodPro);
            $data=$this->db->query($sql,$param);
            return $data;
        }catch(Exception $e){
          $this->Estado=-1;
          $this->Mensaje='Error en el proceso, consulte con el administrador.';
          $this->MensajeError=$e->getMessage(); 
        }
    }
    public function sp_insrt_SolicitudVEPPadre($PerIdenro,$PerParticipacion,$PerTide,$AutoObserv,$PermiEstado,$NumPartida,$UniDeclarante,$AutoSex,$PermiTip,$PermiCodPro){
        try{
            $sql="Call sp_insrt_SolicitudVPadre(?,?,?,?,?,?,?,?,?,?)";
            $param=array($PerIdenro,$PerParticipacion,$PerTide,$AutoObserv,$PermiEstado,$NumPartida,$UniDeclarante,$AutoSex,$PermiTip,$PermiCodPro);
            $data=$this->db->query($sql,$param);
            return $data;
        }catch(Exception $e){
          $this->Estado=-1;
          $this->Mensaje='Error en el proceso, consulte con el administrador.';
          $this->MensajeError=$e->getMessage(); 
        }
    }

}