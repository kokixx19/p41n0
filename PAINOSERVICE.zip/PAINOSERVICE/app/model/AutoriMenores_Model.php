<?php


header('Access-Control-Allow-Origin: *'); 
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');

header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
require_once dirname(__FILE__, 3) . "./app/db/DB.php";
require_once dirname(__FILE__, 3) . "./app/services/GeneralServices.php";

class AutoriMenores_Model
{
    public function __construct()
    {
        $this->db = new Conexion;
    }

    public function get_personaXnumdoc($PerTide,$PerIdeNro)
    {
        try {
            $sql = 'Call sp_sel_personaXnumdoc2(?,?)';
            $param = array($PerTide, $PerIdeNro);
            $data = $this->db->query($sql,$param);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }

     public function get_DomicilioXnumdoc($PerTide,$PerIdeNro)
    {
        try {
            $sql = 'Call sp_sel_Domicilio(?,?)';
            $param = array($PerTide, $PerIdeNro);
            $data = $this->db->query($sql,$param);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }

    public function get_HijosxPadre($PerIdeNroP,$PerTIdeP){
        try{
            $sql='Call sp_get_HijosxPadre(?,?)';
            $param=array($PerIdeNroP,$PerTIdeP);
            $data=$this->db->query($sql,$param);
            return $data;
        } catch(Exception $e){
          $this->Estado=-1;
          $this->Mensaje='Error en el proceso, consulte con el admnistrador.';
          $this->MensajeError=$e->getMessage();
        }
    }

    public function get_HijosxMadre($PerIdeNroM,$PerTIdeM){
        try{
            $sql='Call sp_get_HijosxMadre(?,?)';
            $param=array($PerIdeNroM,$PerTIdeM);
            $data=$this->db->query($sql,$param);
            return $data;
        }catch(Exception $e){
            $this->Estado=-1;
            $this->Mensaje='Error en el proceso, consulte con el administrador.';
            $this->MensajeError=$e->getMessage();
        }
    }

    public function sp_sel_Hijos($PerIdeNro,$PerTIde){
        try{
            $sql='Call sp_sel_Hijos(?,?)';
            $param=array($PerIdeNro,$PerTIde);
            $data=$this->db->query($sql,$param);
            return $data;
        } catch(Exception $e){
          $this->Estado=-1;
          $this->Mensaje='Error en el proceso, consulte con el admnistrador.';
          $this->MensajeError=$e->getMessage();
        }
    }

    public function get_HijosxPadreyMadre($PerIdeNroP,$PerTIdeP,$PerIdeNroM,$PerTIdeM){
      try{
          $sql='Call sp_get_HijosxPadreyMadre(?,?,?,?)';
          $param=array($PerIdeNroP,$PerTIdeP,$PerIdeNroM,$PerTIdeM);
          $data=$this->db->query($sql,$param);
          return $data;
        }catch(Exception $e){
          $this->Estado=-1;
          $this->Mensaje='Error en el proceso, consulte con el administrador.';
          $this->MensajeError=$e->getMessage();
        }
    }
    public function sel_DomicilioUpdt($PerDirCod,$PerTide,$PerIdeNro){
        try{
            $sql='Call sp_sel_DomicilioUpdt(?,?,?)';
            $param=array($PerDirCod,$PerTide,$PerIdeNro);
            $data=$this->db->query($sql,$param);
            return $data;
          }catch(Exception $e){
            $this->Estado=-1;
            $this->Mensaje='Error en el proceso, consulte con el administrador.';
            $this->MensajeError=$e->getMessage();
          }
      }

}