<?php
require_once dirname(__FILE__, 3) . "./app/libs/functions.php";
require_once dirname(__FILE__, 3) . "./app/model/Combos_Model.php";

//header("Content-Type: application/json; charset=UTF-8");
header('Access-Control-Allow-Origin: *');
session_start();
$_POST['op'] = isset($_POST['op']) ? $_POST['op'] : die();




switch ($_POST['op']) {

    case 'get_DocsIdentidad':

        $cm = new Combos_Model;
        $dataDB = $cm->get_DocsIdentidad();
        echo json_encode($dataDB);
        break;

    case 'get_EstadoCivil':

        $cm = new Combos_Model;
        $dataDB = $cm->get_EstadoCivil();
        echo json_encode($dataDB);
        break;

    case 'get_Nacionalidad':

        $cm = new Combos_Model;
        $dataDB = $cm->get_Nacionalidad();
        echo json_encode($dataDB);
        break;

    case 'get_Departamento':

        $cm = new Combos_Model;
        $dataDB = $cm->get_Departamento();
        echo json_encode($dataDB);
        break;

    case 'get_Provincia':
        $cm = new Combos_Model;
        $dataDB = $cm->get_Provincia($_POST['depart']);
        echo json_encode($dataDB);
        break;

    case 'get_Distrito':
        $cm = new Combos_Model;
        $dataDB = $cm->get_Distrito($_POST['depart'],$_POST['distrito']);
        echo json_encode($dataDB);
        break;

    default:
        # code...
        break;
}
