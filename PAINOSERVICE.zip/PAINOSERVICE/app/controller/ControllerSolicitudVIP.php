<?php

header('Access-Control-Allow-Origin: *'); 
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');

header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
require_once dirname(__FILE__, 3) . "./app/libs/functions.php";
require_once dirname(__FILE__, 3) . "./app/model/ModelSolicitudVIP.php";
header('Access-Control-Allow-Origin: *');
session_start();
$_POST['op'] = isset($_POST['op']) ? $_POST['op'] : die();


switch ($_POST['op']) {
    case 'inst_SolicitudVIP';
        $cm=new SolicitudVIP;
        $dataDB=$cm->inst_SolicitudVIP($_POST['PerIdenro'],$_POST['PerParticipacion'],$_POST['PerTide'],$_POST['AutoObserv'],$_POST['UniDeclarante'],$_POST['PermiEstado'],$_POST['PermiCodPro'],$_POST['PerIdenroR'],$_POST['PerTideR']);
        echo $dataDB;
    break;
    case 'sp_insrt_SolicitudVIPPadre';
        $cm=new SolicitudVIP;
        $dataDB=$cm->sp_insrt_SolicitudVIPPadre($_POST['PerIdenro'],$_POST['PerParticipacion'],$_POST['PerTide'],$_POST['AutoObserv'],$_POST['UniDeclarante'],$_POST['PermiEstado'],$_POST['PermiCodPro']);
        echo $dataDB;
    break;
    case 'sp_insrt_SolicitudVIPHijo';
    $cm=new SolicitudVIP;
    $dataDB=$cm->sp_insrt_SolicitudVIPHijo($_POST['PerTideP'],$_POST['PerIdenroP'],$_POST['PerIdenro'],$_POST['PerTide'],$_POST['AutoObserv'],$_POST['NumPartida'],$_POST['AutoTraVia'],$_POST['AutoFchVia'],$_POST['AutoDeclaracion'],$_POST['PermiDestino'],$_POST['PermiTip'],$_POST['PermiCodPro']);
    echo $dataDB;
    break;
    case 'sp_insrt_SolicitudVEPALL';
    $cm=new SolicitudVIP;
    $dataDB=$cm->sp_insrt_SolicitudVEPALL($_POST['PerTideP'],$_POST['PerIdenroP'],$_POST['PerIdenro'],$_POST['PerParticipacion'],$_POST['PerTide'],$_POST['AutoObserv'],$_POST['PermiEstado'],$_POST['NumPartida'],$_POST['UniDeclarante'],$_POST['AutoSex'],$_POST['PermiTip'],$_POST['PermiCodPro']);
    echo $dataDB;
    break;  
    case 'sp_insrt_SolicitudVEPPadre';
    $cm=new SolicitudVIP;
    $dataDB=$cm->sp_insrt_SolicitudVEPPadre($_POST['PerIdenro'],$_POST['PerParticipacion'],$_POST['PerTide'],$_POST['AutoObserv'],$_POST['PermiEstado'],$_POST['NumPartida'],$_POST['UniDeclarante'],$_POST['AutoSex'],$_POST['PermiTip'],$_POST['PermiCodPro']);
    echo $dataDB;
    break;
    default:
    # code...
    break;
}