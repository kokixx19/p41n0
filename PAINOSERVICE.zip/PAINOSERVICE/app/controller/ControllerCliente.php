<?php

header('Access-Control-Allow-Origin: *'); 
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');

header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

require_once dirname(__FILE__, 3) . "./app/libs/functions.php";
require_once dirname(__FILE__, 3) . "./app/model/ModelCliente.php";
header('Access-Control-Allow-Origin: *');
session_start();
$_POST['op'] = isset($_POST['op']) ? $_POST['op'] : die();


switch ($_POST['op']) {
	//fin autenticacion usuario
    case 'get_User';
        $cm=new Cliente;
        $dataDB=$cm->get_User($_POST['user_tmp'],$_POST['pass_tmp']);
        echo json_encode($dataDB);

    break;
    //fin autenticacion usuario
    
    
    case 'insrt_ClienteALL';
        $cm=new Cliente;
        $dataDB=$cm->insrt_ClienteALL(
            $_POST['PerTide'],
            $_POST['PerIdeNro'],
            $_POST['PerTPer'],
            $_POST['PerApePat'],
            $_POST['PerApeMat'],
            $_POST['PerNom'],
            $_POST['PerNomCo'],
            $_POST['PerECiv'],
            $_POST['PerNacion'],
            $_POST['PerTlfNro'],
            $_POST['PerEmail'],
            $_POST['PerObser'],
            $_POST['PerAnuFch'],
            $_POST['PerConyTIde'],
            $_POST['PerConyIde'],
            $_POST['OcuCod'],
            $_POST['PerDirDes'],
            $_POST['PerTIdeP'],
            $_POST['PerIdeNroP'],
            $_POST['PerTIdeM'],
            $_POST['PerIdeNroM'],
            $_POST['PerFchNac'],
            $_POST['PerRazSoc'],
            $_POST['PerRazSocEmail']);
        echo $dataDB;
    break;
    case 'updt_Cliente';
        $cm=new Cliente;
        $dataDB=$cm->updt_Cliente($_POST['PerApePat'],$_POST['PerApeMat'],$_POST['PerNom'],$_POST['PerECiv'],$_POST['PerNacion'],$_POST['PerEmail'],$_POST['PerTlfNro'],$_POST['PerTIde'],$_POST['PerIdeNro']);
        echo ($dataDB);
    break;
    case 'insrt_Domicilio';
    
         $cm=new Cliente;
         $dataDB=$cm->insrt_Domicilio($_POST['PerTIde'],$_POST['PerIdeNro'],$_POST['PerPais'],$_POST['PerDept'],$_POST['PerProv'],$_POST['PerDist'],$_POST['PerDirecc']);
         echo ($dataDB);
    break;
    case 'updt_ClienteRepresentante';
    $cm=new Cliente;
    $dataDB=$cm->updt_ClienteRepresentante($_POST['PerTide'],$_POST['PerIdeNro'],$_POST['PerApePat'],$_POST['PerApeMat'],$_POST['PerNom'],$_POST['PerNomCo'],$_POST['PerNacion'],$_POST['PerEmail'],$_POST['PerTlfNro'],$_POST['PerObser'],$_POST['PerDirDes']);
    echo $dataDB;
    break;
    case 'updt_Domicilio';
    $cm=new Cliente;
    $dataDB=$cm->updt_Domicilio($_POST['PerPais'],$_POST['PerDept'],$_POST['PerProv'],$_POST['PerDist'],$_POST['PerDirecc'],$_POST['PerTIde'],$_POST['PerIdeNro'],$_POST['PerDirCod']);
    echo $dataDB;
    break;
    case 'dlt_Domicilio';
    $cm=new Cliente;
    $dataDB=$cm->dlt_Domicilio($_POST['PerTIde'],$_POST['PerIdeNro'],$_POST['PerDirCod']);
    echo $dataDB;
    break;
    case 'updt_Hijos';
        $cm=new Cliente;
        $dataDB=$cm->updt_Hijos($_POST['PerApePat'],$_POST['PerApeMat'],$_POST['PerNom'],$_POST['PerNomCo'],$_POST['PerFchNac'],$_POST['PerCliente'],$_POST['PerTide'],$_POST['PerIdeNro']);
        echo $dataDB;
    break;
    case 'dlt_Hijos';
    $cm=new Cliente;
    $dataDB=$cm->dlt_Hijos($_POST['PerTIde'],$_POST['PerIdeNro']);
    echo $dataDB;
    break;
    default:
        # code...
        break;
}