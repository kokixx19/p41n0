<?php

header('Access-Control-Allow-Origin: *'); 
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');

header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
require_once dirname(__FILE__, 3) . "./app/libs/functions.php";
require_once dirname(__FILE__, 3) . "./app/model/ModelPoderes.php";
header('Access-Control-Allow-Origin: *');
session_start();
$_POST['op'] = isset($_POST['op']) ? $_POST['op'] : die();


switch ($_POST['op']) {

    /*CREAR IDENTIDICACISION DE CASO*/
    case 'INSERT_PODERES';
        $cm=new Cliente;
        $dataDB=$cm->INSERT_PODERES($_POST['_PO_T_DOC'],$_POST['_PO_N_DOC'],$_POST['_AP_T_DOC_APO'],$_POST['_AP_N_DOC_APO'],$_POST['_DEC_INFO'],$_POST['_DEC_CONS'],$_POST['_COD_PENSION'],$_POST['_TIP_PENSION'],$_POST['_OBS_REDACT'],$_POST['_N_CUENTA'],$_POST['_CAT_PODER']);
        echo $dataDB;

    break;

    /*FIN IDENTIDICACISION DE CASO*/

    /*CREAR IDENTIDICACISION DE CASO*/
    case 'insrt_Cliente';
        $cm=new Cliente;
        $dataDB=$cm->insrt_Cliente($_POST['PerTIde'],$_POST['PerIdeNro'],$_POST['PerApePat'],$_POST['PerApeMat'],$_POST['PerNom'],$_POST['PerECiv'],$_POST['PerNacion'],$_POST['PerEmail'],$_POST['PerTlfNro']);
        echo $dataDB;

    break;

    /*FIN IDENTIDICACISION DE CASO*/
}
?>